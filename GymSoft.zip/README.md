# GymSoft 
seccion de socios,
en donde se pueda añadir, editar y eliminar nuevos socios
y se muestre en tabla los socios qcon los que se cuenta

Seccion de empleados
en donde se pueda añadir editar y eliminar nuevos empleados
y se muestre en tabla los empleados qcon los que se cuenta.

Seccion de proveedores
en donde se pueda añadir editar y eliminar nuevos proveedores
y se muestre en tabla los proveedores qcon los que se cuenta.


Seccion para controlar cada ingreso y egreso que genera cada
grupo de personas
***--(Esto lo tengo planeado hacer con codigos de barra o
codigo qr, que el soscio tenga un codigo ya sea de barras
o qr y cuando llegue al gym exista un lector de estos
y esa sea la manera de controlar su ingreso <<Asi mismo que
cuando este por vencerse o ya este vencido salga una
alerta>>)---*

*******una seccion en la que los grupos de perosnas se vea como en la imagen de ejemplo
para asi poder tomar las asistencias de la gente,
(Tipo cine--ver imgEjemplo.jpg).

Contorl de los gastos por dia, desde venta de cada cosa (toallas, agua, membresias)
